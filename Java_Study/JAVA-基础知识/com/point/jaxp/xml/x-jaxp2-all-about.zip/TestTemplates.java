import java.io.File;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class TestTemplates {

  public static void main(String[] args) {
    if (args.length != 2) {
      System.err.println ("Usage: java TestTemplates " +
                          "[XML filename] [XSL stylesheet]");
      System.exit (1);
    }

    try {
      // Set up input documents
      Source inputXML = new StreamSource(
        new File("phonebook.xml"));

      Source inputXSL = new StreamSource(
        new File("phonebook.xsl"));

      // Set up output sink
      Result outputXHTML = new StreamResult(
        new File("output-templates.html"));

      // Setup a factory for transforms
      TransformerFactory factory = TransformerFactory.newInstance();

      // Pre-compile instructions
      Templates templates = factory.newTemplates(inputXSL);

      // Get a transformer for this XSL
      Transformer transformer = templates.newTransformer();

      // Perform the transformation
      transformer.transform(inputXML, outputXHTML);
    } catch (TransformerConfigurationException e) {
      System.out.println("The underlying XSL processor " +
        "does not support the requested features.");
    } catch (TransformerException e) {
      System.out.println("Error occurred obtaining " +
        "XSL processor.");
    }
  }
}