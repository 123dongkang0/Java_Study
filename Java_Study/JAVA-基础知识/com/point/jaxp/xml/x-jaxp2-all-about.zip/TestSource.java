import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.transform.Source;
import javax.xml.transform.Result;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

public class TestSource {

  public static InputStream getInputStream() throws Exception {
    return new FileInputStream(new File("phonebook.xml"));
  }

  public static OutputStream getOutputStream() throws Exception {
    return new FileOutputStream(new File("output.xml"));
  }

  // Placeholder function
  public static Document getDocument() {
    return null;
  }

  // Placeholder function
  public static XMLReader getXMLReader() {
    return null;
  }

  public static InputSource getInputSource() throws Exception {
    return new InputSource(
      new FileInputStream(new File("phonebook.xml")));
  }

  public static void main(String[] args) throws Exception {
    // Create a Source from a file on disk
    Source fileSource = 
      new StreamSource(new File("phonebook.xml"));
 
    // Create a Source from a DOM tree
    Document myDomDocument = getDocument();
    Source domSource = new DOMSource(myDomDocument);

    // Create a Source from an InputStream
    BufferedInputStream bis = 
      new BufferedInputStream(getInputStream());
    Source streamSource = new StreamSource(bis);

    // Create a Source from a reader and SAX InputSource
    XMLReader myXMLReader = getXMLReader();
    InputSource myInputSource = getInputSource();
    Source saxSource = new SAXSource(myXMLReader, myInputSource);

    // Write to a file on disk
    Result fileResult = 
      new StreamResult(new File("output.xml"));
 
    // Write a Result to a DOM tree (inserted into the supplied Document)
    /*Document*/ myDomDocument = getDocument();
    Result domResult = new DOMResult(myDomDocument);

    // Create a Result from an OutputStream
    BufferedOutputStream bos = 
      new BufferedOutputStream(getOutputStream());
    Result streamResult = new StreamResult(bos);

    // Create a Result to write to a SAX ContentHandler
    ContentHandler myContentHandler = new MyContentHandler();
    Result saxResult = new SAXResult(myContentHandler);
  }

}

class MyContentHandler extends org.xml.sax.helpers.DefaultHandler { }